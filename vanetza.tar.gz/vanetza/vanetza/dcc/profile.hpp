#ifndef PROFILE_HPP_V9RMCGL2
#define PROFILE_HPP_V9RMCGL2

namespace vanetza
{
namespace dcc
{

enum class Profile : unsigned
{
    DP0,
    DP1,
    DP2,
    DP3
};

} // namespace dcc
} // namespace vanetza

#endif /* PROFILE_HPP_V9RMCGL2 */

