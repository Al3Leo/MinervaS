#ifndef LIFETIME_HPP_XYTSNW3J
#define LIFETIME_HPP_XYTSNW3J

#include <vanetza/common/bit_number.hpp>
#include <vanetza/geonet/serialization.hpp>
#include <vanetza/units/time.hpp>
#include <boost/operators.hpp>
#include <cstdint>

namespace vanetza
{
namespace geonet
{

class Lifetime : public boost::totally_ordered<Lifetime>
{
public:
    static constexpr uint8_t multiplier_mask = 0xFC;
    static constexpr uint8_t base_mask = 0x03;

    enum class Base {
        Fifty_Milliseconds = 0,
        One_Second = 1,
        Ten_Seconds = 2,
        Hundred_Seconds = 3
    };

    static const Lifetime zero();

    Lifetime();
    Lifetime(Base base, BitNumber<uint8_t, 6> multiplier);
    void set(Base base, BitNumber<uint8_t, 6> multiplier);
    uint8_t raw() const { return m_lifetime; }
    void raw(uint8_t raw) { m_lifetime = raw; }

    bool operator<(const Lifetime&) const;
    bool operator==(const Lifetime&) const;

    /**
     * Decodes stored lifetime
     * \return lifetime as duration quantity
     */
    units::Duration decode() const;

    /**
     * Encode duration in lifetime object
     * \note Precision loss might occur
     * \param duration Lifetime duration
     */
    void encode(units::Duration);

private:
    uint8_t m_lifetime;
};

void serialize(const Lifetime&, OutputArchive&);
void deserialize(Lifetime&, InputArchive&);

} // namespace geonet
} // namespace vanetza

#endif /* LIFETIME_HPP_XYTSNW3J */

