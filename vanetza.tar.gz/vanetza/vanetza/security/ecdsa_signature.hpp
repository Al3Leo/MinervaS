#ifndef DE8C4D2A_5F0C_4721_9DAC_6986B2CA54D4
#define DE8C4D2A_5F0C_4721_9DAC_6986B2CA54D4

namespace vanetza
{
namespace security
{

} // namespace security
} // namespace vanetza

#endif /* DE8C4D2A_5F0C_4721_9DAC_6986B2CA54D4 */
