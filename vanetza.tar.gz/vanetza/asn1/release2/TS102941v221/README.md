The TS 102941 v2.2.1 PKI ASN1 files are copied from its [ETSI repository](https://forge.etsi.org/rep/ITS/asn1/pki_ts102941/-/tree/v2.2.1).

See [ETSI License](https://forge.etsi.org/rep/ITS/asn1/pki_ts102941/-/blob/v2.2.1/LICENSE) for copyright details.
