The TS 103300 v2.2.1 VAM ASN1 files are copied from its [ETSI repository](https://forge.etsi.org/rep/ITS/asn1/vam-ts103300_3/-/tree/v.2.2.1).
For compatibility with CDD 2.2.1, the CDD import lines are manually patched from "major-version-3" to "major-version-4".

See [ETSI License](https://forge.etsi.org/rep/ITS/asn1/vam-ts103300_3/-/blob/v.2.2.1/LICENSE) for copyright details.
