The TS 103324 v2.1.1 CPM ASN1 files are copied from its [ETSI repository](https://forge.etsi.org/rep/ITS/asn1/cpm_ts103324/-/tree/v2.1.1).
For compatibility with CDD 2.2.1, the CDD import lines are manually patched from "major-version-3" to "major-version-4".

See [ETSI License](https://forge.etsi.org/rep/ITS/asn1/cpm_ts103324/-/blob/v2.1.1/LICENSE) for copyright details.
